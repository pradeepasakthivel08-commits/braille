@echo off
setlocal EnableDelayedExpansion
title Braille Guardian - Launcher
cd /d "%~dp0"

rem ---- ANSI colour codes (Windows 10+) ----
for /F %%a in ('powershell -NoProfile -Command "[char]27"') do set "ESC=%%a"
set "RED=%ESC%[91m"
set "GREEN=%ESC%[92m"
set "YELLOW=%ESC%[93m"
set "BLUE=%ESC%[94m"
set "MAGENTA=%ESC%[95m"
set "CYAN=%ESC%[96m"
set "WHITE=%ESC%[97m"
set "BOLD=%ESC%[1m"
set "RESET=%ESC%[0m"

cls
echo.
echo %CYAN%%BOLD%  ============================================%RESET%
echo %MAGENTA%%BOLD%      BRAILLE GUARDIAN  -  DASHBOARD + ESP%RESET%
echo %CYAN%%BOLD%  ============================================%RESET%
echo.

rem ---- 1. Check Python ----
echo %YELLOW%[1/5]%WHITE% Checking Python...%RESET%
python --version >nul 2>&1
if errorlevel 1 (
    echo %RED%  X Python not found. Install it from https://www.python.org and tick "Add to PATH".%RESET%
    goto :fail
)
echo %GREEN%  OK Python found.%RESET%

rem ---- 2. Check Java ----
echo %YELLOW%[2/5]%WHITE% Checking Java...%RESET%
java -version >nul 2>&1
if errorlevel 1 (
    echo %RED%  X Java not found. Install JDK 11 or newer from https://adoptium.net%RESET%
    goto :fail
)
echo %GREEN%  OK Java found.%RESET%

rem ---- 3. Install requirements ----
echo %YELLOW%[3/5]%WHITE% Installing requirements...%RESET%
python -m pip install -q -r requirements.txt
if errorlevel 1 (
    echo %RED%  X Could not install requirements. Check your internet connection.%RESET%
    goto :fail
)
echo %GREEN%  OK Requirements installed.%RESET%

rem ---- 4. ESP address ----
echo %YELLOW%[4/5]%WHITE% ESP8266 address%RESET%
echo %BLUE%  Connect this PC to the ESP WiFi "BRAILLE-GENERATOR" (default 192.168.4.1),%RESET%
echo %BLUE%  or type the ESP's IP if it is on your home WiFi.%RESET%
set "ESP_IP=192.168.4.1"
set /p "ESP_IP=%CYAN%  ESP IP [192.168.4.1]: %RESET%"
if "%ESP_IP%"=="" set "ESP_IP=192.168.4.1"
echo %GREEN%  OK Using http://%ESP_IP%%RESET%

rem ---- 5. Start everything ----
echo %YELLOW%[5/5]%WHITE% Starting services...%RESET%
start "Java Backend (port 8080)" cmd /k "title Java Backend ^& color 0B ^& java BrailleServer.java http://%ESP_IP%"
timeout /t 4 /nobreak >nul
echo %GREEN%  OK Java backend started on port 8080.%RESET%

echo.
echo %MAGENTA%%BOLD%  Dashboard:%RESET% %WHITE%http://localhost:8501%RESET%
echo %YELLOW%  Press Ctrl+C here to stop the dashboard. Close the Java window to stop the backend.%RESET%
echo.
start "" http://localhost:8501
python -m streamlit run dashboard.py --server.headless true
goto :end

:fail
echo.
echo %RED%%BOLD%  Setup failed. Fix the problem above and run this file again.%RESET%

:end
echo.
echo %CYAN%  Stopped.%RESET%
pause
endlocal
