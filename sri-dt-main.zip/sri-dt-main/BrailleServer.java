import com.sun.net.httpserver.HttpServer;
import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

// Backend: converts normal text into Braille (English Grade 1).
// Run:  java BrailleServer.java
public class BrailleServer {

    static final Map<Character, Character> LETTERS = new HashMap<>();
    static final Map<Character, Character> DIGITS = new HashMap<>();
    static final Map<Character, Character> PUNCT = new HashMap<>();

    static final char NUMBER_SIGN = '\u283C';
    static final char CAPITAL_SIGN = '\u2820';

    static {
        String letters = "abcdefghijklmnopqrstuvwxyz";
        String braille = "⠁⠃⠉⠙⠑⠋⠛⠓⠊⠚⠅⠇⠍⠝⠕⠏⠟⠗⠎⠞⠥⠧⠺⠭⠽⠵";
        for (int i = 0; i < letters.length(); i++) {
            LETTERS.put(letters.charAt(i), braille.charAt(i));
        }
        String digits = "1234567890";
        String digitBraille = "⠁⠃⠉⠙⠑⠋⠛⠓⠊⠚";
        for (int i = 0; i < digits.length(); i++) {
            DIGITS.put(digits.charAt(i), digitBraille.charAt(i));
        }
        PUNCT.put('.', '⠲');
        PUNCT.put(',', '⠂');
        PUNCT.put('?', '⠦');
        PUNCT.put('!', '⠖');
        PUNCT.put(';', '⠆');
        PUNCT.put(':', '⠒');
        PUNCT.put('-', '⠤');
        PUNCT.put(' ', ' ');
        PUNCT.put('\n', '\n');
    }

    static String toBraille(String text) {
        StringBuilder out = new StringBuilder();
        boolean inNumber = false;
        for (char ch : text.toCharArray()) {
            if (Character.isDigit(ch) && DIGITS.containsKey(ch)) {
                if (!inNumber) {
                    out.append(NUMBER_SIGN);
                    inNumber = true;
                }
                out.append(DIGITS.get(ch));
                continue;
            }
            inNumber = false;
            if (Character.isUpperCase(ch)) {
                out.append(CAPITAL_SIGN);
            }
            char lower = Character.toLowerCase(ch);
            if (LETTERS.containsKey(lower)) {
                out.append(LETTERS.get(lower));
            } else if (PUNCT.containsKey(ch)) {
                out.append(PUNCT.get(ch));
            }
        }
        return out.toString();
    }

    static void send(com.sun.net.httpserver.HttpExchange ex, int code, String body) throws IOException {
        byte[] bytes = body.getBytes(StandardCharsets.UTF_8);
        ex.getResponseHeaders().set("Content-Type", "text/plain; charset=utf-8");
        ex.sendResponseHeaders(code, bytes.length);
        try (OutputStream os = ex.getResponseBody()) {
            os.write(bytes);
        }
    }

    // ESP8266 address. Override: java BrailleServer.java http://192.168.1.50
    // (192.168.4.1 is the ESP's own access-point address.)
    static String espUrl = "http://192.168.4.1";

    static String[] espGet(String method, String path) throws IOException {
        java.net.HttpURLConnection con =
            (java.net.HttpURLConnection) new java.net.URL(espUrl + path).openConnection();
        con.setRequestMethod(method);
        if (method.equals("POST")) {
            con.setDoOutput(true);
            con.setFixedLengthStreamingMode(0);
            con.getOutputStream().close();
        }
        con.setConnectTimeout(3000);
        con.setReadTimeout(10000);
        int code = con.getResponseCode();
        java.io.InputStream in = code < 400 ? con.getInputStream() : con.getErrorStream();
        String body = in == null ? "" : new String(in.readAllBytes(), StandardCharsets.UTF_8);
        con.disconnect();
        return new String[]{String.valueOf(code), body};
    }

    static void proxy(com.sun.net.httpserver.HttpExchange ex, String method, String path) throws IOException {
        try {
            String[] r = espGet(method, path);
            ex.getResponseHeaders().set("Content-Type", "text/plain; charset=utf-8");
            byte[] b = r[1].getBytes(StandardCharsets.UTF_8);
            ex.sendResponseHeaders(Integer.parseInt(r[0]), b.length);
            try (OutputStream os = ex.getResponseBody()) { os.write(b); }
        } catch (IOException e) {
            send(ex, 502, "ESP8266 not reachable at " + espUrl);
        }
    }

    public static void main(String[] args) throws IOException {
        if (args.length > 0) espUrl = args[0].replaceAll("/+$", "");
        int port = 8080;
        HttpServer server = HttpServer.create(new InetSocketAddress(port), 0);

        server.createContext("/health", ex -> send(ex, 200, "ok"));

        // ---- ESP8266 bridge ----
        server.createContext("/esp/state", ex -> proxy(ex, "GET", "/state"));
        server.createContext("/esp/trigger", ex -> proxy(ex, "POST", "/trigger"));
        server.createContext("/esp/off", ex -> proxy(ex, "POST", "/off"));
        server.createContext("/esp/select", ex -> {
            String q = ex.getRequestURI().getQuery();
            if (q == null || !q.matches("mask=\\d{1,2}&char=[A-J0-9]?")
                    || Integer.parseInt(q.substring(5).split("&")[0]) > 15) {
                send(ex, 400, "Invalid mask");
                return;
            }
            proxy(ex, "GET", "/select?" + q);
        });

        server.createContext("/convert", ex -> {
            if (!ex.getRequestMethod().equalsIgnoreCase("POST")) {
                send(ex, 405, "Use POST");
                return;
            }
            String text = new String(ex.getRequestBody().readAllBytes(), StandardCharsets.UTF_8);
            send(ex, 200, toBraille(text));
        });

        server.start();
        System.out.println("Braille backend running on http://localhost:" + port);
        System.out.println("ESP8266 target: " + espUrl);
    }
}
