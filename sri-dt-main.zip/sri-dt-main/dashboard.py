import time

import numpy as np
import pandas as pd
import plotly.express as px
import requests
import streamlit as st
from bs4 import BeautifulSoup
from pypdf import PdfReader

st.set_page_config(page_title="Braille Guardian Dashboard", layout="wide")

MAX_CHARS = 50000


# ---------- Backend (Java) ----------
def convert_with_backend(text):
    url = st.session_state.backend_url.rstrip("/") + "/convert"
    response = requests.post(url, data=text.encode("utf-8"), timeout=15)
    response.raise_for_status()
    return response.text


def backend_online():
    try:
        url = st.session_state.backend_url.rstrip("/") + "/health"
        return requests.get(url, timeout=2).status_code == 200
    except requests.RequestException:
        return False


# ---------- ESP8266 device (via Java backend) ----------
def _esp_base():
    return st.session_state.backend_url.rstrip("/") + "/esp"


def esp_state():
    """Live state from the ESP, or None if unreachable."""
    try:
        r = requests.get(_esp_base() + "/state", timeout=4)
        return r.json() if r.status_code == 200 else None
    except (requests.RequestException, ValueError):
        return None


# Four-dot patterns (dots 1,2,4,5) used by the ESP firmware; bit i = servo i.
ALPHA_PATTERNS = ["1000", "1100", "1010", "1011", "1001",
                  "1110", "1111", "1101", "0110", "0111"]
NUMBER_PATTERNS = ["0111", "1000", "1100", "1010", "1011",
                   "1001", "1110", "1111", "1101", "0110"]
SUPPORTED = "ABCDEFGHIJ0123456789"


def char_pattern(ch):
    if ch.isalpha():
        return ALPHA_PATTERNS[ord(ch) - 65]
    return NUMBER_PATTERNS[int(ch)]


def pattern_mask(pattern):
    return sum(1 << i for i, bit in enumerate(pattern) if bit == "1")


def esp_send(ch):
    """Select a character (A-J, 0-9) and raise its servos. Returns (ok, message)."""
    mask = pattern_mask(char_pattern(ch))
    try:
        r = requests.get(_esp_base() + "/select",
                         params={"mask": mask, "char": ch}, timeout=5)
        if r.status_code != 200:
            return False, r.text
        r = requests.post(_esp_base() + "/trigger", timeout=10)
        return r.status_code == 200, r.text
    except requests.RequestException as error:
        return False, f"Device unreachable: {error}"


def esp_off():
    try:
        r = requests.post(_esp_base() + "/off", timeout=5)
        return r.status_code == 200, r.text
    except requests.RequestException as error:
        return False, f"Device unreachable: {error}"


MAX_PLAY_LETTERS = 50  # the device shows one character (A-J, 0-9) at a time


def wait_for_phase(phase, timeout=15):
    """Poll the ESP until it reports the given phase (HOLDING or ALL DOWN)."""
    end = time.time() + timeout
    time.sleep(0.5)
    while time.time() < end:
        st_ = esp_state()
        if st_ is not None and st_.get("phase") == phase:
            return True
        time.sleep(0.4)
    return False


HOLD_SECONDS = 3  # how long each character stays raised for the reader


def play_on_device(text):
    """Send each A-J letter or digit of the text to the device, one after another."""
    letters = [c.upper() for c in text if c.isascii() and c.upper() in SUPPORTED]
    if not letters:
        st.warning("The text has no A-J letters or digits. The device can only show A-J and 0-9.")
        return
    if len(letters) > MAX_PLAY_LETTERS:
        st.info(f"Playing the first {MAX_PLAY_LETTERS} of {len(letters)} letters.")
        letters = letters[:MAX_PLAY_LETTERS]
    if esp_state() is None:
        st.error("ESP8266 not reachable. Check the Java backend and the device.")
        return

    bar = st.progress(0.0)
    status = st.empty()
    for i, letter in enumerate(letters, 1):
        status.write(f"Letter {i} of {len(letters)}: **{letter}**")
        ok, msg = esp_send(letter)
        if not ok:
            st.error(f"Stopped at '{letter}': {msg}")
            return
        if not wait_for_phase("HOLDING"):
            st.error("Servos did not finish raising. Stopped.")
            return
        time.sleep(HOLD_SECONDS)  # reader feels the character
        esp_off()
        if not wait_for_phase("ALL DOWN"):
            st.error("Servos did not lower. Stopped.")
            return
        bar.progress(i / len(letters))
    status.success(f"Done. Played {len(letters)} letters.")


# ---------- Readers ----------
def read_pdf(file):
    return "\n".join(page.extract_text() or "" for page in PdfReader(file).pages)


def read_website(url):
    html = requests.get(url, timeout=10).text
    soup = BeautifulSoup(html, "html.parser")
    for tag in soup(["script", "style", "nav", "footer"]):
        tag.decompose()
    return soup.get_text(separator="\n", strip=True)


# ---------- Sample data (replace with real data later) ----------
@st.cache_data
def progress_data():
    rng = np.random.default_rng(7)
    courses = ["English", "Maths", "Science", "History", "Computer Basics"]
    return pd.DataFrame({
        "course": courses,
        "progress": rng.integers(40, 100, len(courses)),
        "score": rng.integers(55, 98, len(courses)),
        "hours": rng.integers(8, 40, len(courses)),
    })


@st.cache_data
def weekly_data():
    rng = np.random.default_rng(3)
    weeks = [f"Week {i}" for i in range(1, 9)]
    return pd.DataFrame({
        "week": weeks,
        "reading_hours": rng.integers(2, 10, 8),
        "pages_read": rng.integers(20, 120, 8),
    })


# ---------- Session defaults ----------
defaults = {
    "backend_url": "http://localhost:8080",
    "guardian_name": "Guardian Name",
    "guardian_email": "guardian@example.com",
    "student_name": "Student Name",
    "weekly_goal": 8,
    "alerts": True,
    "books": [],
    "device": {"battery": 78, "connected": True, "firmware": "1.0.3",
               "cells": 40, "last_sync": "Today, 9:30 AM", "language": "English"},
}
for key, value in defaults.items():
    st.session_state.setdefault(key, value)

# ---------- Sidebar ----------
st.sidebar.title("Braille Dashboard")
st.sidebar.caption(f"Guardian: {st.session_state.guardian_name}")
page = st.sidebar.radio(
    "Menu",
    ["Overview", "Scan Book", "Learning Progress", "Device Status", "Profile & Settings"],
)
st.sidebar.divider()
if backend_online():
    st.sidebar.success("Conversion service: online")
else:
    st.sidebar.error("Conversion service: offline")

student = st.session_state.student_name
device = st.session_state.device

# ---------- Pages ----------
if page == "Overview":
    st.title("Overview")
    st.caption(f"Student: {student}")

    df = progress_data()
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Overall progress", f"{df['progress'].mean():.0f}%")
    c2.metric("Average score", f"{df['score'].mean():.0f}")
    c3.metric("Books scanned", len(st.session_state.books))
    c4.metric("Device", "Online" if esp_state() else "Offline")

    left, right = st.columns(2)
    left.plotly_chart(
        px.bar(df, x="course", y="progress", title="Progress by course (%)"),
        use_container_width=True)
    right.plotly_chart(
        px.line(weekly_data(), x="week", y="reading_hours", markers=True,
                title="Weekly reading hours"),
        use_container_width=True)

elif page == "Scan Book":
    st.title("Scan Book")
    st.write("Upload a book or a website. It is converted to Braille by the backend.")

    tab_file, tab_web, tab_text = st.tabs(["Upload book / file", "Website", "Paste text"])
    title, text = "", ""

    with tab_file:
        file = st.file_uploader("Choose a PDF or TXT file", type=["pdf", "txt"])
        if file:
            title = file.name
            text = read_pdf(file) if file.name.lower().endswith(".pdf") else file.read().decode("utf-8", "ignore")

    with tab_web:
        url = st.text_input("Website link")
        if url:
            title = url
            try:
                text = read_website(url)
            except requests.RequestException as error:
                st.error(f"Could not open the website: {error}")

    with tab_text:
        pasted = st.text_area("Type or paste text", height=150)
        if pasted:
            title, text = "Pasted text", pasted

    if text:
        st.info(f"Text found: {len(text)} characters")
        if len(text) > MAX_CHARS:
            st.warning(f"Only the first {MAX_CHARS} characters will be converted.")
            text = text[:MAX_CHARS]

        if st.button("Convert to Braille", type="primary"):
            try:
                braille = convert_with_backend(text)
                st.session_state.books.append(
                    {"title": title, "text": text, "braille": braille})
                st.success("Converted successfully.")
            except requests.RequestException:
                st.error("Conversion service is offline. Start the Java backend first.")

    if st.session_state.books:
        st.subheader("Scanned books")
        for idx in reversed(range(len(st.session_state.books))):
            book = st.session_state.books[idx]
            with st.expander(book["title"]):
                a, b = st.columns(2)
                a.markdown("**Original text**")
                a.text(book["text"][:1500])
                b.markdown("**Braille**")
                b.text(book["braille"][:1500])
                st.download_button("Download Braille", book["braille"],
                                   file_name="braille_output.txt",
                                   key=f"dl_{idx}")
                if st.button("Play on device", key=f"play_{idx}"):
                    play_on_device(book["text"])

elif page == "Learning Progress":
    st.title("Learning Progress")
    st.caption(f"Student: {student}")

    df = progress_data()
    goal = st.session_state.weekly_goal
    this_week = int(weekly_data()["reading_hours"].iloc[-1])
    st.write(f"Weekly reading goal: {this_week} of {goal} hours")
    st.progress(min(this_week / goal, 1.0))

    left, right = st.columns(2)
    left.plotly_chart(
        px.bar(df, x="course", y="progress", title="Course completion (%)"),
        use_container_width=True)
    right.plotly_chart(
        px.bar(df, x="course", y="score", title="Average score"),
        use_container_width=True)

    left, right = st.columns(2)
    left.plotly_chart(
        px.line(weekly_data(), x="week", y="pages_read", markers=True,
                title="Pages read per week"),
        use_container_width=True)
    right.plotly_chart(
        px.pie(df, names="course", values="hours", title="Study time by course"),
        use_container_width=True)

    st.subheader("Course details")
    st.dataframe(df, use_container_width=True, hide_index=True)

elif page == "Device Status":
    st.title("Braille Device Status")

    @st.fragment(run_every=2)
    def live_status():
        s = esp_state()
        c1, c2, c3 = st.columns(3)
        if s is None:
            c1.metric("Connection", "Disconnected")
            c2.metric("Selected letter", "-")
            c3.metric("Servos", "-")
            st.error("ESP8266 not reachable. Check the Java backend is running "
                     "with the ESP's IP: java BrailleServer.java http://<esp-ip>")
            return
        c1.metric("Connection", "Connected")
        c2.metric("Selected mask", s.get("selected", 0))
        c3.metric("Servos", "MOVING" if s.get("running") else "IDLE")
        angles = s.get("angles", [0, 0, 0, 0])
        st.table(pd.DataFrame({
            "Item": ["ESP IP", "Phase", "Servo 1 / 2 / 4 / 5"],
            "Value": [s.get("ip", "--"), s.get("phase", "--"),
                      " / ".join("UP" if a > 0 else "down" for a in angles)],
        }))

    live_status()

    st.subheader("Send a letter to the device")
    letter = st.selectbox("Character (A-J or 0-9)", list(SUPPORTED))
    st.caption(f"Pattern: {char_pattern(letter)}")
    b1, b2 = st.columns(2)
    if b1.button("Send to device", type="primary"):
        ok, msg = esp_send(letter)
        (st.success if ok else st.error)(msg)
    if b2.button("Turn off all servos"):
        ok, msg = esp_off()
        (st.success if ok else st.error)(msg)

else:
    st.title("Profile & Settings")

    st.subheader("Guardian profile")
    st.session_state.guardian_name = st.text_input("Name", st.session_state.guardian_name)
    st.session_state.guardian_email = st.text_input("Email", st.session_state.guardian_email)

    st.subheader("Student")
    st.session_state.student_name = st.text_input("Student name", st.session_state.student_name)
    st.session_state.weekly_goal = st.number_input(
        "Weekly reading goal (hours)", 1, 40, st.session_state.weekly_goal)

    st.subheader("Preferences")
    st.subheader("Backend")
    st.session_state.backend_url = st.text_input("Conversion service URL",
                                                 st.session_state.backend_url)
    st.success("Changes are saved automatically for this session.")
